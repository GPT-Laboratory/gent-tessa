
#!/bin/bash

# TESSA Offline - macOS Installer
# Version 1.0 Release Candidate

set -e

echo "=================================="
echo "  TESSA Offline - macOS Setup"
echo "=================================="

# Step 1: Check Ollama installation
echo ""
echo "Checking Ollama..."

if ! command -v ollama >/dev/null 2>&1; then
    echo "Ollama is not installed."
    echo "Please install Ollama from:"
    echo "https://ollama.com/download"
    echo "Then run this installer again."
    read -r -p "Press Enter to exit..."
    exit 1
fi

echo "Ollama found."

# Step 2: Check Ollama service
echo ""
echo "Checking Ollama service..."

if ! ollama list >/dev/null 2>&1; then
    echo "Cannot connect to Ollama."
    echo "Please open the Ollama application and try again."
    read -r -p "Press Enter to exit..."
    exit 1
fi

# Step 3: Install required model
echo ""
echo "Checking qwen3:14b..."

if ollama list | awk 'NR > 1 {print $1}' | grep -Fxq "qwen3:14b"; then
    echo "qwen3:14b is already installed."
else
    echo "Downloading qwen3:14b..."
    echo "Internet access is required for this step."
    ollama pull qwen3:14b
fi

echo ""
echo "Ollama model setup completed."
echo ""
echo "Next: Install AnythingLLM Desktop from:"
echo "https://anythingllm.com/desktop"
echo ""
echo "Then configure TESSA using:"
echo "TESSA-Configuration/TESSA-Configuration.txt"
echo ""
echo "This script does not yet import the TESSA workspace."
echo "Clean installation testing is still required."
echo ""
read -r -p "Press Enter to finish..."
