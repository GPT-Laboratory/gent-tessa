
# TESSA Offline - Windows Installer
# Version 1.0 Release Candidate

$ErrorActionPreference = "Stop"

Write-Host "=================================="
Write-Host "  TESSA Offline - Windows Setup"
Write-Host "=================================="

# Step 1: Check Ollama installation
Write-Host "`nChecking Ollama..."

if (-not (Get-Command ollama -ErrorAction SilentlyContinue)) {
    Write-Host "Ollama is not installed or is not on PATH."
    Write-Host "Install Ollama from:"
    Write-Host "https://ollama.com/download/windows"
    Read-Host "Press Enter to exit"
    exit 1
}

Write-Host "Ollama found."

# Step 2: Check Ollama service
Write-Host "`nChecking Ollama service..."

try {
    $null = & ollama list 2>&1
    if ($LASTEXITCODE -ne 0) {
        throw "Ollama service unavailable"
    }
}
catch {
    Write-Host "Cannot connect to Ollama."
    Write-Host "Please start Ollama and run this script again."
    Read-Host "Press Enter to exit"
    exit 1
}

# Step 3: Check required model
Write-Host "`nChecking qwen3:14b..."

$models = & ollama list

if ($models -match '(^|\s)qwen3:14b(\s|$)') {
    Write-Host "qwen3:14b is already installed."
}
else {
    Write-Host "Downloading qwen3:14b..."
    Write-Host "Internet access is required."

    & ollama pull qwen3:14b

    if ($LASTEXITCODE -ne 0) {
        Write-Host "Model download failed."
        Read-Host "Press Enter to exit"
        exit 1
    }
}

Write-Host "`nOllama model setup completed."

# Step 4: AnythingLLM instructions
Write-Host "`nNext: Install AnythingLLM Desktop from:"
Write-Host "https://anythingllm.com/desktop"

Write-Host "`nThen configure TESSA using:"
Write-Host "TESSA-Configuration/TESSA-Configuration.txt"

Write-Host "`nThis script does not yet import the TESSA workspace."
Write-Host "Clean installation testing is still required."

Read-Host "`nPress Enter to finish"
