# TESSA Offline — Knowledge Version

- Package: TESSA Offline
- Version: 1.0.0-rc1
- Knowledge cut-off: 18 March 2026
- Initial validation date: 27 August 2026
- Retrieval-fix validation date: Pending final verification
- Primary source: `Navigating Compliance.pdf` — *Navigating Compliance: Strategic Guidance for SMEs under the EU AI Act*
- Secondary source: `TESSA_Offline_Use_Case_Reference.md`, derived from `Use case AI list.xlsx`
- Retrieval aid: `TESSA_Offline_Priority_Use_Case_Index.md`
- Approved regulatory updates installed: None

## Source hierarchy

1. Regulation (EU) 2024/1689 (EU AI Act) is the authoritative source for binding legal definitions, obligations, exceptions, and requirements.
2. *Navigating Compliance: Strategic Guidance for SMEs under the EU AI Act* is the primary educational guidance source.
3. European Commission guidance provides official, non-binding interpretation where applicable.
4. `TESSA_Offline_Use_Case_Reference.md` provides secondary educational, non-definitive risk classifications.
5. `TESSA_Offline_Priority_Use_Case_Index.md` is a retrieval aid derived from the full use-case reference.
6. Approved offline regulatory updates may supplement the package when explicitly installed and dated.

## Offline limitation

No approved regulatory update installed in this package does not mean that no external update exists. TESSA Offline cannot verify developments after the knowledge cut-off without a reviewed package update.

