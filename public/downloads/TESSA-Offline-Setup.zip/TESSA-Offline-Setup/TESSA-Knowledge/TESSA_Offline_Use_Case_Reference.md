# TESSA Offline — EU AI Act Use-Case Orientation Reference

## Purpose and limitations

This file is a retrieval-friendly conversion of `Use case AI list.xlsx` for TESSA Offline.

- It is an educational orientation and initial risk-screening aid based on Regulation (EU) 2024/1689 (EU AI Act).
- It is not legally authoritative, legally definitive, or legal advice.
- The primary source for TESSA responses remains the book `Navigating Compliance: Strategic Guidance for SMEs under the EU AI Act`.
- If this file conflicts with the book, follow the book.
- A listed risk category is an illustrative starting point only. Actual classification depends on the system's intended purpose, context, affected persons, role, and other facts.
- Blank `Type` cells in the workbook have been filled from the nearest preceding nonblank cell so every record can be retrieved with its sector or group.
- Exact duplicate rows have been merged; all original Excel row numbers are retained in `Source row(s)`.

When referring to an entry in an answer, use this label:

> Similar use case from the use-case file based on Regulation (EU) 2024/1689 (EU AI Act) — educational orientation only.

## File summary

- Original data rows: 101
- Unique retrieval records: 93
- Exact duplicate rows merged: 8
- High: 37 unique records
- Limited: 28 unique records
- Minimal: 20 unique records
- Prohibited / Unacceptable: 8 unique records

## Use-case records

### 001 — AI chatbot for support

- Sector or group: IT
- Use case: AI chatbot for support
- Illustrative risk category: Limited
- Notes: Needs transparency notice
- Why it may be a risk: Not stated
- Source row(s): 2
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 002 — Resume screening AI

- Sector or group: IT
- Use case: Resume screening AI
- Illustrative risk category: High
- Notes: Requires human oversight
- Why it may be a risk: Not stated
- Source row(s): 3
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 003 — Predictive maintenance tool

- Sector or group: IT
- Use case: Predictive maintenance tool
- Illustrative risk category: Minimal
- Notes: Voluntary guidelines only
- Why it may be a risk: Not stated
- Source row(s): 4
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 004 — AI-generated marketing text

- Sector or group: IT
- Use case: AI-generated marketing text
- Illustrative risk category: Limited
- Notes: Be cautious with claims
- Why it may be a risk: Not stated
- Source row(s): 5
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 005 — AI-based proctoring during exams

- Sector or group: IT
- Use case: AI-based proctoring during exams
- Illustrative risk category: High
- Notes: Privacy and discrimination concerns
- Why it may be a risk: Not stated
- Source row(s): 6
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 006 — Facial recognition for access control

- Sector or group: IT
- Use case: Facial recognition for access control
- Illustrative risk category: High
- Notes: Risk of bias and surveillance
- Why it may be a risk: Not stated
- Source row(s): 7
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 007 — Speech-to-text transcription

- Sector or group: IT
- Use case: Speech-to-text transcription
- Illustrative risk category: Minimal
- Notes: Check for accuracy and dialect inclusion
- Why it may be a risk: Not stated
- Source row(s): 8
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 008 — Customer behavior prediction

- Sector or group: IT
- Use case: Customer behavior prediction
- Illustrative risk category: Limited
- Notes: Be clear about profiling and consent
- Why it may be a risk: Not stated
- Source row(s): 9
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 009 — AI image recognition in manufacturing

- Sector or group: IT
- Use case: AI image recognition in manufacturing
- Illustrative risk category: Minimal
- Notes: Mostly operational; low ethical risk
- Why it may be a risk: Not stated
- Source row(s): 10
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 010 — AI-driven hiring recommendation tool

- Sector or group: IT
- Use case: AI-driven hiring recommendation tool
- Illustrative risk category: High
- Notes: Potential for indirect bias and legal scrutiny
- Why it may be a risk: Not stated
- Source row(s): 11
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 011 — Social media content moderation AI

- Sector or group: IT
- Use case: Social media content moderation AI
- Illustrative risk category: High
- Notes: False positives/negatives; appeals necessary
- Why it may be a risk: Not stated
- Source row(s): 12
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 012 — AI writing assistant for internal memos

- Sector or group: IT
- Use case: AI writing assistant for internal memos
- Illustrative risk category: Limited
- Notes: Watch for hallucination and source integrity
- Why it may be a risk: Not stated
- Source row(s): 13
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 013 — Translation AI for multilingual communication

- Sector or group: IT
- Use case: Translation AI for multilingual communication
- Illustrative risk category: Limited
- Notes: Review for cultural/contextual accuracy
- Why it may be a risk: Not stated
- Source row(s): 14
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 014 — AI scheduling assistant

- Sector or group: IT
- Use case: AI scheduling assistant
- Illustrative risk category: Minimal
- Notes: Privacy notice required
- Why it may be a risk: Not stated
- Source row(s): 15
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 015 — AI tutor or learning assistant

- Sector or group: Education
- Use case: AI tutor or learning assistant
- Illustrative risk category: Limited
- Notes: Must disclose AI use to learners
- Why it may be a risk: Not stated
- Source row(s): 16
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 016 — Automated grading systems

- Sector or group: Education
- Use case: Automated grading systems
- Illustrative risk category: Limited
- Notes: Can reflect bias; needs manual review
- Why it may be a risk: Not stated
- Source row(s): 17
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 017 — Plagiarism detection tools

- Sector or group: Education
- Use case: Plagiarism detection tools
- Illustrative risk category: Limited
- Notes: Ensure accuracy and allow appeals
- Why it may be a risk: Not stated
- Source row(s): 18
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 018 — Student mental health chatbots

- Sector or group: Education
- Use case: Student mental health chatbots
- Illustrative risk category: High
- Notes: Must involve human professionals and confidentiality safeguards
- Why it may be a risk: Not stated
- Source row(s): 19
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 019 — AI student admission or exam evaluation system

- Sector or group: Education; etc.
- Use case: AI student admission or exam evaluation system
- Illustrative risk category: High
- Notes: Includes scoring, admissions, or automated assessment systems
- Why it may be a risk: May significantly affect access to education and educational opportunities
- Source row(s): 20, 88
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 020 — AI diagnostic systems

- Sector or group: Healthcare
- Use case: AI diagnostic systems
- Illustrative risk category: High
- Notes: Must meet medical device regulations
- Why it may be a risk: May affect healthcare decisions and patient outcomes
- Source row(s): 21
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 021 — AI triage tools (symptom checker)

- Sector or group: Healthcare
- Use case: AI triage tools (symptom checker)
- Illustrative risk category: High
- Notes: Transparency and disclaimers critical
- Why it may be a risk: Not stated
- Source row(s): 22
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 022 — Medical image analysis (X-ray, MRI)

- Sector or group: Healthcare
- Use case: Medical image analysis (X-ray, MRI)
- Illustrative risk category: High
- Notes: Requires human oversight
- Why it may be a risk: Not stated
- Source row(s): 23
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 023 — Patient risk prediction models

- Sector or group: Healthcare
- Use case: Patient risk prediction models
- Illustrative risk category: High
- Notes: Can reinforce systemic biases
- Why it may be a risk: Not stated
- Source row(s): 24
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 024 — Robot-assisted surgery

- Sector or group: Healthcare
- Use case: Robot-assisted surgery
- Illustrative risk category: High
- Notes: Safety-critical; full human control required
- Why it may be a risk: Not stated
- Source row(s): 25
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 025 — AI hospital appointment prioritisation system

- Sector or group: Healthcare; etc.
- Use case: AI hospital appointment prioritisation system
- Illustrative risk category: High
- Notes: Human review may still be required
- Why it may be a risk: May influence access to healthcare services
- Source row(s): 26, 95
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 026 — Predictive maintenance

- Sector or group: Manufacturing
- Use case: Predictive maintenance
- Illustrative risk category: Minimal
- Notes: Mostly operational; low ethical concern
- Why it may be a risk: Not stated
- Source row(s): 27
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 027 — Defect detection using AI vision

- Sector or group: Manufacturing
- Use case: Defect detection using AI vision
- Illustrative risk category: Limited
- Notes: Ensure continuous calibration
- Why it may be a risk: Not stated
- Source row(s): 28
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 028 — Supply chain optimization

- Sector or group: Manufacturing
- Use case: Supply chain optimization
- Illustrative risk category: Limited
- Notes: Risk of transparency loss
- Why it may be a risk: Not stated
- Source row(s): 29
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 029 — AI-powered robotics for assembly

- Sector or group: Manufacturing
- Use case: AI-powered robotics for assembly
- Illustrative risk category: Limited
- Notes: Occupational safety and training needs
- Why it may be a risk: Not stated
- Source row(s): 30
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 030 — AI for energy efficiency in buildings

- Sector or group: Environment
- Use case: AI for energy efficiency in buildings
- Illustrative risk category: Minimal
- Notes: Mostly technical, but ensure consent for sensor data
- Why it may be a risk: Not stated
- Source row(s): 31
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 031 — Deforestation detection via satellite AI

- Sector or group: Environment
- Use case: Deforestation detection via satellite AI
- Illustrative risk category: Limited
- Notes: Accuracy and model integrity key
- Why it may be a risk: Not stated
- Source row(s): 32
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 032 — Climate change prediction modeling

- Sector or group: Environment
- Use case: Climate change prediction modeling
- Illustrative risk category: Limited
- Notes: Requires transparency on uncertainties
- Why it may be a risk: Not stated
- Source row(s): 33
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 033 — Wildlife monitoring with computer vision

- Sector or group: Environment
- Use case: Wildlife monitoring with computer vision
- Illustrative risk category: Limited
- Notes: Must avoid misuse of tracking data
- Why it may be a risk: Not stated
- Source row(s): 34
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 034 — AI in water quality monitoring

- Sector or group: Environment
- Use case: AI in water quality monitoring
- Illustrative risk category: Minimal
- Notes: Technical calibration is primary concern
- Why it may be a risk: Not stated
- Source row(s): 35
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 035 — Predictive policing

- Sector or group: Social / Public Sector
- Use case: Predictive policing
- Illustrative risk category: High
- Notes: Major bias, transparency, and ethical concerns
- Why it may be a risk: Not stated
- Source row(s): 36
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 036 — Welfare eligibility assessment

- Sector or group: Social / Public Sector
- Use case: Welfare eligibility assessment
- Illustrative risk category: High
- Notes: Must include appeal mechanisms and human oversight
- Why it may be a risk: Not stated
- Source row(s): 37
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 037 — Smart city surveillance

- Sector or group: Social / Public Sector
- Use case: Smart city surveillance
- Illustrative risk category: High
- Notes: Privacy and mass surveillance issues
- Why it may be a risk: Not stated
- Source row(s): 38
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 038 — AI in public transportation optimization

- Sector or group: Social / Public Sector
- Use case: AI in public transportation optimization
- Illustrative risk category: Limited
- Notes: Focus on inclusiveness and accessibility
- Why it may be a risk: Not stated
- Source row(s): 39
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 039 — Social benefit fraud detection

- Sector or group: Social / Public Sector
- Use case: Social benefit fraud detection
- Illustrative risk category: High
- Notes: Risk of discrimination; oversight required
- Why it may be a risk: Not stated
- Source row(s): 40
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 040 — Crop health monitoring using drones

- Sector or group: Food & Agriculture
- Use case: Crop health monitoring using drones
- Illustrative risk category: Limited
- Notes: Environmental impact of tech deployment
- Why it may be a risk: Not stated
- Source row(s): 41
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 041 — AI-based yield prediction

- Sector or group: Food & Agriculture
- Use case: AI-based yield prediction
- Illustrative risk category: Minimal
- Notes: Accuracy and data integration are key
- Why it may be a risk: Not stated
- Source row(s): 42
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 042 — Food safety inspection using AI vision

- Sector or group: Food & Agriculture
- Use case: Food safety inspection using AI vision
- Illustrative risk category: Minimal
- Notes: Human confirmation often needed
- Why it may be a risk: Not stated
- Source row(s): 43
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 043 — AI for personalized nutrition

- Sector or group: Food & Agriculture
- Use case: AI for personalized nutrition
- Illustrative risk category: Minimal
- Notes: Must avoid health misinformation
- Why it may be a risk: Not stated
- Source row(s): 44
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 044 — Supply chain AI in food logistics

- Sector or group: Food & Agriculture
- Use case: Supply chain AI in food logistics
- Illustrative risk category: Limited
- Notes: Ensure fairness for small producers
- Why it may be a risk: Not stated
- Source row(s): 45
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 045 — Generative AI (text/image/video)

- Sector or group: General / Cross-Sectoral
- Use case: Generative AI (text/image/video)
- Illustrative risk category: High
- Notes: Risk of misinformation and deepfakes
- Why it may be a risk: Not stated
- Source row(s): 46
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 046 — Voice cloning and synthesis

- Sector or group: General / Cross-Sectoral
- Use case: Voice cloning and synthesis
- Illustrative risk category: High
- Notes: Requires consent and anti-fraud safeguards
- Why it may be a risk: Not stated
- Source row(s): 47
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 047 — AI-powered search engines

- Sector or group: General / Cross-Sectoral
- Use case: AI-powered search engines
- Illustrative risk category: Limited
- Notes: Risk of hallucinated answers; disclaimers needed
- Why it may be a risk: Not stated
- Source row(s): 48
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 048 — AI email summarizers

- Sector or group: General / Cross-Sectoral
- Use case: AI email summarizers
- Illustrative risk category: Minimal
- Notes: Data handling transparency required
- Why it may be a risk: Not stated
- Source row(s): 49
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 049 — AI-powered decision support systems

- Sector or group: General / Cross-Sectoral
- Use case: AI-powered decision support systems
- Illustrative risk category: Minimal
- Notes: Ensure explainability and audit trails
- Why it may be a risk: Not stated
- Source row(s): 50
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 050 — AI-based contract review

- Sector or group: Legal & Compliance
- Use case: AI-based contract review
- Illustrative risk category: Minimal
- Notes: Can miss nuance; legal liability issues
- Why it may be a risk: Not stated
- Source row(s): 51
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 051 — Legal research assistants

- Sector or group: Legal & Compliance
- Use case: Legal research assistants
- Illustrative risk category: Limited
- Notes: Must verify sources and citations
- Why it may be a risk: Not stated
- Source row(s): 52
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 052 — Litigation outcome prediction

- Sector or group: Legal & Compliance
- Use case: Litigation outcome prediction
- Illustrative risk category: High
- Notes: Can perpetuate systemic bias
- Why it may be a risk: Not stated
- Source row(s): 53
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 053 — AI vocational training recommendation system

- Sector or group: Legal & Compliance; etc.
- Use case: AI vocational training recommendation system
- Illustrative risk category: High
- Notes: Human oversight is important
- Why it may be a risk: May influence educational or career opportunities
- Source row(s): 54, 89
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 054 — AI recruitment CV screening tool

- Sector or group: Legal & Compliance; etc.
- Use case: AI recruitment CV screening tool
- Illustrative risk category: High
- Notes: Common SME HR use case
- Why it may be a risk: May affect employment access and candidate selection
- Source row(s): 55, 90
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 055 — AI employee productivity or performance monitoring

- Sector or group: Legal & Compliance; etc.
- Use case: AI employee productivity or performance monitoring
- Illustrative risk category: High
- Notes: Requires transparency and governance
- Why it may be a risk: May impact worker evaluation, promotion, or dismissal decisions
- Source row(s): 56, 91
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 056 — Policy simulation and impact analysis

- Sector or group: Government & Policy
- Use case: Policy simulation and impact analysis
- Illustrative risk category: Minimal
- Notes: Transparency in assumptions required
- Why it may be a risk: Not stated
- Source row(s): 57
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 057 — Citizenship and visa application bots

- Sector or group: Government & Policy
- Use case: Citizenship and visa application bots
- Illustrative risk category: High
- Notes: Risk of bias, errors, and appeal needs
- Why it may be a risk: Not stated
- Source row(s): 58
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 058 — AI for census data analysis

- Sector or group: Government & Policy
- Use case: AI for census data analysis
- Illustrative risk category: Limited
- Notes: Anonymization is key
- Why it may be a risk: Not stated
- Source row(s): 59
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 059 — AI crime risk prediction system

- Sector or group: Government & Policy; etc.
- Use case: AI crime risk prediction system
- Illustrative risk category: High
- Notes: Certain predictive policing uses may become prohibited
- Why it may be a risk: May affect law enforcement decisions and individual rights
- Source row(s): 60, 96
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 060 — AI recommendation systems

- Sector or group: Retail & E-commerce
- Use case: AI recommendation systems
- Illustrative risk category: Limited
- Notes: May lead to filter bubbles
- Why it may be a risk: Not stated
- Source row(s): 61
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 061 — Dynamic pricing algorithms

- Sector or group: Retail & E-commerce
- Use case: Dynamic pricing algorithms
- Illustrative risk category: Minimal
- Notes: Needs fairness oversight
- Why it may be a risk: Not stated
- Source row(s): 62
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 062 — AI-powered virtual fitting rooms

- Sector or group: Retail & E-commerce
- Use case: AI-powered virtual fitting rooms
- Illustrative risk category: Limited
- Notes: Ensure body image sensitivity
- Why it may be a risk: Not stated
- Source row(s): 63
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 063 — AI video editing tools

- Sector or group: Media & Entertainment
- Use case: AI video editing tools
- Illustrative risk category: Limited
- Notes: Watch for copyright violations
- Why it may be a risk: Not stated
- Source row(s): 64
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 064 — Deepfake content generation

- Sector or group: Media & Entertainment
- Use case: Deepfake content generation
- Illustrative risk category: High
- Notes: Significant risk of misinformation
- Why it may be a risk: Not stated
- Source row(s): 65
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 065 — AI-curated playlists or content

- Sector or group: Media & Entertainment
- Use case: AI-curated playlists or content
- Illustrative risk category: Minimal
- Notes: Personalization vs. diversity trade-offs
- Why it may be a risk: Not stated
- Source row(s): 66
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 066 — Credit scoring AI

- Sector or group: Finance & Insurance
- Use case: Credit scoring AI
- Illustrative risk category: High
- Notes: Often biased; explainability essential
- Why it may be a risk: Not stated
- Source row(s): 67
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 067 — Fraud detection in banking

- Sector or group: Finance & Insurance
- Use case: Fraud detection in banking
- Illustrative risk category: Minimal
- Notes: Must allow human override
- Why it may be a risk: Not stated
- Source row(s): 68
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 068 — AI in insurance claims processing

- Sector or group: Finance & Insurance
- Use case: AI in insurance claims processing
- Illustrative risk category: Minimal
- Notes: Bias and appeal rights must be clear
- Why it may be a risk: Not stated
- Source row(s): 69
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 069 — AI credit scoring or loan approval system

- Sector or group: Finance & Insurance; etc.
- Use case: AI credit scoring or loan approval system
- Illustrative risk category: High
- Notes: Bias and explainability concerns
- Why it may be a risk: May affect access to essential financial services
- Source row(s): 70, 92
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 070 — AI insurance eligibility assessment

- Sector or group: Finance & Insurance; etc.
- Use case: AI insurance eligibility assessment
- Illustrative risk category: High
- Notes: Requires careful data governance
- Why it may be a risk: May influence access to essential services
- Source row(s): 71, 93
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 071 — AI in route optimization

- Sector or group: Transportation & Logistics
- Use case: AI in route optimization
- Illustrative risk category: Limited
- Notes: Efficiency gain with minimal risks
- Why it may be a risk: Not stated
- Source row(s): 72
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 072 — Self-driving vehicle AI

- Sector or group: Transportation & Logistics
- Use case: Self-driving vehicle AI
- Illustrative risk category: High
- Notes: Safety-critical; regulatory compliance required
- Why it may be a risk: Not stated
- Source row(s): 73
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 073 — Cargo inspection with computer vision

- Sector or group: Transportation & Logistics
- Use case: Cargo inspection with computer vision
- Illustrative risk category: Limited
- Notes: Operational impact; data integrity needed
- Why it may be a risk: Not stated
- Source row(s): 74
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 074 — AI in site safety monitoring

- Sector or group: Construction & Real Estate
- Use case: AI in site safety monitoring
- Illustrative risk category: Limited
- Notes: Privacy for workers must be considered
- Why it may be a risk: Not stated
- Source row(s): 75
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 075 — Building energy modeling

- Sector or group: Construction & Real Estate
- Use case: Building energy modeling
- Illustrative risk category: Minimal
- Notes: Focused on efficiency, low human risk
- Why it may be a risk: Not stated
- Source row(s): 76
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 076 — AI for property valuation

- Sector or group: Construction & Real Estate
- Use case: AI for property valuation
- Illustrative risk category: Minimal
- Notes: Transparency needed to avoid unfair pricing
- Why it may be a risk: Not stated
- Source row(s): 77
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 077 — AI for threat detection and response

- Sector or group: Cybersecurity
- Use case: AI for threat detection and response
- Illustrative risk category: Limited
- Notes: Overreliance can miss novel attacks
- Why it may be a risk: Not stated
- Source row(s): 78
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 078 — AI-generated phishing detection

- Sector or group: Cybersecurity
- Use case: AI-generated phishing detection
- Illustrative risk category: Limited
- Notes: Requires constant model updates
- Why it may be a risk: Not stated
- Source row(s): 79
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 079 — Manipulative or deceptive AI that causes harm

- Sector or group: etc.
- Use case: Manipulative or deceptive AI that causes harm
- Illustrative risk category: Prohibited / Unacceptable
- Notes: Use as a screening flag. Needs legal review, especially where behavioural influence, deception, or harm is involved.
- Why it may be a risk: May materially distort a person’s behaviour or decision-making in a way that causes, or is likely to cause, significant harm.
- Source row(s): 80
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 080 — AI exploitation of vulnerable persons

- Sector or group: etc.
- Use case: AI exploitation of vulnerable persons
- Illustrative risk category: Prohibited / Unacceptable
- Notes: Relevant for systems targeting children, elderly people, patients, workers, or financially vulnerable users. Needs careful assessment.
- Why it may be a risk: May exploit vulnerabilities linked to age, disability, or specific social or economic situation, leading to harmful or unfair outcomes.
- Source row(s): 81
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 081 — AI social scoring of customers or citizens

- Sector or group: etc.
- Use case: AI social scoring of customers or citizens
- Illustrative risk category: Prohibited / Unacceptable
- Notes: Avoid broad scoring systems that rank people across contexts. Needs legal review.
- Why it may be a risk: May lead to unjustified or harmful treatment based on social behaviour, personal characteristics, or broad trustworthiness scoring.
- Source row(s): 82
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 082 — Biometric categorisation based on sensitive traits

- Sector or group: etc.
- Use case: Biometric categorisation based on sensitive traits
- Illustrative risk category: Prohibited / Unacceptable
- Notes: High legal sensitivity. Some technical or lawful uses may differ, so classification should not be treated as final without expert review.
- Why it may be a risk: Certain biometric categorisation systems may infer or categorise sensitive characteristics such as race, political opinions, trade union membership, religious beliefs, sex life, or sexual orientation.
- Source row(s): 83
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 083 — Untargeted scraping of facial images for facial recognition databases

- Sector or group: etc.
- Use case: Untargeted scraping of facial images for facial recognition databases
- Illustrative risk category: Prohibited / Unacceptable
- Notes: Relevant for facial recognition, surveillance, security, or identity-verification providers. High legal risk.
- Why it may be a risk: May involve creating or expanding facial recognition databases through untargeted scraping from the internet or CCTV footage.
- Source row(s): 84
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 084 — Emotion recognition in workplace or education contexts

- Sector or group: etc.
- Use case: Emotion recognition in workplace or education contexts
- Illustrative risk category: Prohibited / Unacceptable
- Notes: Important for HR monitoring, productivity tools, proctoring, classroom analytics, and employee wellbeing tools. Exceptions may apply in limited safety or medical contexts.
- Why it may be a risk: Certain AI systems used to infer emotions in workplaces or educational institutions may be prohibited, except where legally allowed.
- Source row(s): 85
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 085 — Predictive policing based mainly on profiling or personal traits

- Sector or group: etc.
- Use case: Predictive policing based mainly on profiling or personal traits
- Illustrative risk category: Prohibited / Unacceptable
- Notes: Relevant for law-enforcement analytics vendors. Needs strict legal review and should not be simplified as ordinary risk scoring.
- Why it may be a risk: Certain predictive policing uses may be prohibited when they assess or predict a person’s risk of committing offences based mainly on profiling, personality traits, or characteristics.
- Source row(s): 86
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 086 — Real-time remote biometric identification in public spaces

- Sector or group: etc.
- Use case: Real-time remote biometric identification in public spaces
- Illustrative risk category: Prohibited / Unacceptable
- Notes: Very high legal sensitivity. Exceptions are narrow and context-specific; SMEs should seek legal review before developing or deploying such systems.
- Why it may be a risk: Real-time remote biometric identification in publicly accessible spaces for law-enforcement purposes is generally prohibited, except for limited legal exceptions.
- Source row(s): 87
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 087 — AI medical triage or diagnosis support tool

- Sector or group: etc.
- Use case: AI medical triage or diagnosis support tool
- Illustrative risk category: High
- Notes: Often requires additional sector regulation
- Why it may be a risk: May affect healthcare decisions and patient outcomes
- Source row(s): 94
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 088 — AI border risk assessment system

- Sector or group: etc.
- Use case: AI border risk assessment system
- Illustrative risk category: High
- Notes: High legal sensitivity
- Why it may be a risk: May affect migration or asylum decisions
- Source row(s): 97
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 089 — AI asylum application assessment support

- Sector or group: etc.
- Use case: AI asylum application assessment support
- Illustrative risk category: High
- Notes: Requires strong human oversight
- Why it may be a risk: May influence immigration outcomes
- Source row(s): 98
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 090 — AI legal decision recommendation system

- Sector or group: etc.
- Use case: AI legal decision recommendation system
- Illustrative risk category: High
- Notes: Human authority must remain responsible
- Why it may be a risk: May influence judicial or administrative decisions
- Source row(s): 99
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 091 — AI voter influence or political targeting analytics

- Sector or group: etc.
- Use case: AI voter influence or political targeting analytics
- Illustrative risk category: High
- Notes: Transparency obligations may also apply
- Why it may be a risk: May affect democratic processes and public trust
- Source row(s): 100
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 092 — AI safety monitoring component in industrial machinery

- Sector or group: etc.
- Use case: AI safety monitoring component in industrial machinery
- Illustrative risk category: High
- Notes: Often linked to product safety law
- Why it may be a risk: May affect physical safety and regulated product compliance
- Source row(s): 101
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.

### 093 — AI autonomous transport safety control system

- Sector or group: etc.
- Use case: AI autonomous transport safety control system
- Illustrative risk category: High
- Notes: Sector-specific safety requirements apply
- Why it may be a risk: May impact transport safety decisions
- Source row(s): 102
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.
