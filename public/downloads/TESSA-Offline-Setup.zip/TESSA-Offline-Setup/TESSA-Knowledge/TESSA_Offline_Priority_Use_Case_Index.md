# TESSA Offline — Priority Use-Case Index

Purpose: improve retrieval of representative use cases during testing. This is a retrieval aid derived from `TESSA_Offline_Use_Case_Reference.md`. It is secondary to the book and does not change the source records.

Important: fields labelled **Retrieval keywords** are indexing metadata only. They are not evidence and must never be quoted or cited as source content. Use only the exact evidence fields when answering: Use case, Illustrative risk category, Notes, Why it may be a risk, Source row(s), Source, and Authority status. Do not combine records.

## AI recruitment CV screening tool

- Use case: AI recruitment CV screening tool
- Illustrative risk category: High
- Notes: Common SME HR use case
- Why it may be a risk: May affect employment access and candidate selection
- Source row(s): 55, 90
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.
- Retrieval keywords: CV screening, resume screening, job applicant screening, candidate selection, recommend candidates, interview recommendation, recruitment, hiring, employment, HR, provider develops or sells, deployer buys or uses, importer, distributor

## Resume screening AI

- Use case: Resume screening AI
- Illustrative risk category: High
- Notes: Requires human oversight
- Why it may be a risk: Not stated
- Source row(s): 3
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.
- Retrieval keywords: resume, CV, screening, recruitment, hiring, applicant, candidate

## AI-driven hiring recommendation tool

- Use case: AI-driven hiring recommendation tool
- Illustrative risk category: High
- Notes: Potential for indirect bias and legal scrutiny
- Why it may be a risk: Not stated
- Source row(s): 11
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.
- Retrieval keywords: hiring recommendation, recommend candidates, interview, recruitment, employment, HR

## Emotion recognition in workplace or education contexts

- Use case: Emotion recognition in workplace or education contexts
- Illustrative risk category: Prohibited / Unacceptable
- Notes: Important for HR monitoring, productivity tools, proctoring, classroom analytics, and employee wellbeing tools. Exceptions may apply in limited safety or medical contexts.
- Why it may be a risk: Certain AI systems used to infer emotions in workplaces or educational institutions may be prohibited, except where legally allowed.
- Source row(s): 85
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.
- Retrieval keywords: webcam, infer emotion, employee engagement, workplace monitoring, productivity monitoring, school, education, proctoring, wellbeing

## AI chatbot for support

- Use case: AI chatbot for support
- Illustrative risk category: Limited
- Notes: Needs transparency notice
- Why it may be a risk: Not stated
- Source row(s): 2
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.
- Retrieval keywords: chatbot, customer support, virtual assistant, conversational AI, transparency notice

## AI credit scoring or loan approval system

- Use case: AI credit scoring or loan approval system
- Illustrative risk category: High
- Notes: Bias and explainability concerns
- Why it may be a risk: May affect access to essential financial services
- Source row(s): 70, 92
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.
- Retrieval keywords: credit score, loan approval, lending, bank, finance, financial services, eligibility

## AI medical triage or diagnosis support tool

- Use case: AI medical triage or diagnosis support tool
- Illustrative risk category: High
- Notes: Often requires additional sector regulation
- Why it may be a risk: May affect healthcare decisions and patient outcomes
- Source row(s): 94
- Source: `Use case AI list.xlsx`
- Authority status: Educational orientation only; not legally definitive.
- Retrieval keywords: medical triage, diagnosis support, clinical decision support, healthcare, patient, hospital

