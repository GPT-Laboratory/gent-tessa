# TESSA Offline — Installation Guide
Version: 1.0 (Release Candidate)
Updated: 30 October 2026

## 1. About TESSA Offline

TESSA Offline is a locally operated educational AI governance assistant for small and medium-sized enterprises (SMEs) seeking to understand the EU AI Act. It uses AnythingLLM Desktop, Ollama, and locally stored reference documents. A ChatGPT account or OpenAI API key is not required.

TESSA provides educational orientation, not legal advice or a definitive legal compliance determination. The knowledge cut-off stated in its system prompt is 18 March 2026; later developments may not be included.

## 2. Release status and supported platforms

This is a RELEASE CANDIDATE, not a validated public release. The package contains guided installation scripts for macOS and Windows. The existing installation has been developed on macOS; a fresh-computer installation, Windows compatibility, and offline operation have NOT yet been independently verified. Do not describe the package as a fully automatic installer.

## 3. System requirements

- macOS or Windows computer capable of running AnythingLLM Desktop and Ollama.
- Sufficient available RAM and disk space for the qwen3:14b local model, AnythingLLM, embeddings, and the knowledge documents. Exact minimum requirements have not been established by this project; verify on the target computer before installation.
- Internet connection for downloading software and the model during initial setup.
- Permission to install desktop applications and run a local setup script.
- For offline use: all required software, model weights, embedding components, and knowledge documents must already be installed locally.

## 4. Required software

- Ollama: https://ollama.com/download
- AnythingLLM Desktop (evaluated version: v1.16.0): https://anythingllm.com/desktop
- Ollama model: qwen3:14b

The setup scripts do not install Ollama or AnythingLLM automatically. They check Ollama availability and download the model if necessary.

## 5. Package contents

TESSA-Offline-Setup/
  Installation-Guide/README.txt
  Install-TESSA/macOS/Install-TESSA-Mac.command
  Install-TESSA/Windows/Install-TESSA-Windows.ps1
  TESSA-Configuration/TESSA-Configuration.txt
  TESSA-Configuration/TESSA-System-Prompt.txt
  TESSA-Knowledge/ (knowledge files)
  Licence-Information/LICENCES.txt

The TESSA-Knowledge folder is expected to contain NINE files after adding the separate Article 26 PDF: the book PDF; full EU AI Act PDF; Article 55 PDF; Article 26 PDF; Commission GPAI guidelines PDF; the use-case spreadsheet; and three TESSA Offline Markdown reference files. Check actual filenames and contents against the release folder before distribution. The recorded configuration previously stated seven workspace documents; this count must be reconciled with the actual documents embedded in the workspace. Not every file in the distribution folder is necessarily supported or indexed automatically.

## 6. Installation procedure — macOS

1. Install Ollama from https://ollama.com/download and start the Ollama application.
2. Install AnythingLLM Desktop from https://anythingllm.com/desktop.
3. In the extracted package, locate Install-TESSA/macOS/Install-TESSA-Mac.command.
4. Run the script using your usual trusted local script-launch method. If macOS blocks execution, review the file and use your organisation's approved security procedure; do not disable system protections globally.
5. The script checks the Ollama command and running service. It downloads qwen3:14b if missing; this may take time and requires internet access.
6. When the script finishes, continue with Section 8 to configure AnythingLLM manually.

If the script reports that Ollama cannot be found or contacted, confirm Ollama is installed, running, and available from the terminal, then retry.

## 7. Installation procedure — Windows

1. Install Ollama from https://ollama.com/download/windows and start Ollama.
2. Install AnythingLLM Desktop from https://anythingllm.com/desktop.
3. In the extracted package, locate Install-TESSA/Windows/Install-TESSA-Windows.ps1.
4. Open PowerShell in that folder and run the script using your organisation's approved execution-policy settings. For example, where permitted, execute the script in a PowerShell session with a process-scoped policy rather than changing the policy permanently. Do not run an unreviewed script or disable security protections globally.
5. The script checks the Ollama command and service, then downloads qwen3:14b if missing. Internet access is required for the download.
6. When the script finishes, continue with Section 8 to configure AnythingLLM manually.

If PowerShell blocks the script, consult local IT policy. If Ollama is not found, restart PowerShell after installation and check that Ollama is running.

## 8. Configure AnythingLLM Desktop (both platforms)

1. Launch AnythingLLM Desktop.
2. Select Ollama as the LLM provider.
3. Set the Ollama endpoint to http://127.0.0.1:11434 and select qwen3:14b.
4. Set the model context window to 4096.
5. Select AnythingLLM Embedder, embedding model all-MiniLM-L6-v2, and LanceDB as the vector database.
6. Create a workspace named TESSA Offline.
7. Set workspace Chat Mode to Query and Chat History to 20.
8. Set retrieval Search Preference to Accuracy Optimized, Maximum Context Snippets to 20, and Document Similarity Threshold to No restriction, if these controls are available in the installed version.
9. Open the workspace system-prompt settings. Copy the COMPLETE contents of TESSA-Configuration/TESSA-System-Prompt.txt into the system-prompt field, then save.
10. Compare the resulting settings with TESSA-Configuration/TESSA-Configuration.txt. The text files are reference instructions; they do not automatically import a workspace.

Menu names and setting locations may differ between application versions. Do not assume a workspace export/import feature exists.

## 9. Import the knowledge package

1. Open AnythingLLM's document-management interface.
2. Import supported files from TESSA-Knowledge. Confirm each file is accepted and processed; some versions may not accept every file type directly (particularly spreadsheets). If a file cannot be ingested, use an appropriate supported text format and record the conversion before release.
3. Add or embed the processed documents into the TESSA Offline workspace; uploading alone may not make a document available to retrieval.
4. Wait for indexing and embeddings to complete.
5. Check the workspace document list against the intended knowledge inventory. Confirm the full AI Act, Article 26, Article 55, the book, the Commission guidance, and relevant use-case/reference materials are retrievable.
6. Do not distribute private workspace backups, chat histories, API credentials, or personal files.

## 10. Installation and offline verification checklist

Record the test platform, operating system, AnythingLLM version, Ollama version, installed model, test date, and any errors.

[ ] Software installs and starts without errors.
[ ] Ollama lists qwen3:14b as installed.
[ ] AnythingLLM connects to local Ollama at http://127.0.0.1:11434.
[ ] TESSA Offline workspace settings match the configuration file.
[ ] The complete release system prompt is saved in the workspace.
[ ] Required knowledge documents are embedded and retrievable.
[ ] New conversation: ask "What is the EU AI Act?" and check source attribution.
[ ] Ask a role-specific Article 26 question and verify the answer against the retrieved legal text.
[ ] Test one question each in English, Finnish, and Swedish.
[ ] Disconnect the computer from the internet (including Wi-Fi and Ethernet) and start a NEW conversation.
[ ] Repeat a knowledge-based question; confirm that the response is generated without external connectivity.
[ ] Restart the application while offline and repeat the test, if feasible.
[ ] Record outcomes, limitations, and corrective actions.

Passing an installation test does not establish legal accuracy. Legal responses and citations require separate substantive evaluation.

## 11. Troubleshooting

- Ollama not found: install it, start the application, and reopen the terminal or PowerShell.
- Ollama connection failure: confirm the local Ollama service is running and the endpoint is correct.
- Model missing: connect to the internet and run the setup script again, or use `ollama pull qwen3:14b`.
- Empty or unsupported answers: confirm the source files were successfully processed AND added to the workspace; check retrieval settings.
- Spreadsheet cannot be imported: convert the approved use-case data to a supported text format without changing the records; document the conversion and recheck retrieval.
- Slow or failed generation: check available memory, disk space, and model compatibility. Do not silently substitute a different model in release testing.
- Windows script blocked: follow the local PowerShell execution policy; avoid permanent system-wide changes.

## 12. Licensing, data, and limitations

Before public distribution, review Licence-Information/LICENCES.txt and confirm redistribution rights for every included PDF, spreadsheet, reference file, model-related component, and third-party resource. Public accessibility does not by itself establish redistribution permission.

TESSA runs locally after successful installation and offline verification, but initial downloads require internet access. Do not assume external software updates or live regulatory updates are available offline. Users should verify consequential legal interpretations with authoritative sources and qualified professionals.

## 13. Release gate

Do not label TESSA Offline v1.0 as publicly validated until a clean macOS installation, a clean Windows installation, knowledge ingestion, multilingual checks, and disconnected-network operation have been tested and documented. Resolve any licensing and source-inventory discrepancies before distribution.